// ─────────────────────────────────────────────
// Netlify Serverless Function: Stripe Webhook
// File: netlify/functions/stripe-webhook.js
// ─────────────────────────────────────────────
// Stripe sends a POST here after payment succeeds.
// This is how you KNOW the payment actually went through
// (can't be faked by the customer).
//
// SETUP: In your Stripe Dashboard → Developers → Webhooks
// Add endpoint: https://yoursite.netlify.app/.netlify/functions/stripe-webhook
// Select event: checkout.session.completed

const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }

  const sig = event.headers["stripe-signature"];
  let stripeEvent;

  try {
    // Verify the webhook signature to prevent spoofing
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error("Webhook signature verification failed:", err.message);
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }

  // Handle the event
  if (stripeEvent.type === "checkout.session.completed") {
    const session = stripeEvent.data.object;

    console.log("✅ Payment successful!");
    console.log("Order ID:", session.metadata.orderId);
    console.log("Customer email:", session.customer_email);
    console.log("Amount:", session.amount_total / 100, session.currency.toUpperCase());

    // ──────────────────────────────────────────
    // Here you could:
    // 1. Send a confirmation email
    // 2. Update an order database
    // 3. Trigger shipping label creation
    // 4. Send yourself a notification
    //
    // Example with a database or email service:
    //
    //   await fetch("https://api.sendgrid.com/v3/mail/send", {
    //     method: "POST",
    //     headers: { Authorization: `Bearer ${process.env.SENDGRID_KEY}` },
    //     body: JSON.stringify({
    //       to: session.customer_email,
    //       subject: "Order Confirmed!",
    //       text: `Thanks for your order #${session.metadata.orderId}!`
    //     })
    //   });
    // ──────────────────────────────────────────
  }

  return {
    statusCode: 200,
    body: JSON.stringify({ received: true }),
  };
};
