# Player 1 Supply — Complete Setup Guide

## What You Have

You have a complete e-commerce store with:
- Customer accounts (sign up / sign in)
- Shopping cart with checkout flow
- **Real credit/debit card payments via Stripe** (customers are redirected to Stripe's secure page)
- PayPal payments
- Admin dashboard (products, orders, customers, settings)
- Printable shipping labels
- SHA-256 password hashing, rate limiting, session expiry, input sanitization

## Files Overview

```
your-project/
├── src/
│   └── store.jsx              ← Your store (React component)
├── netlify/
│   └── functions/
│       ├── create-checkout.js ← Creates Stripe payment sessions
│       └── stripe-webhook.js  ← Confirms payments server-side
├── api/
│   └── create-checkout.js     ← Vercel version (use ONE host, not both)
├── package.json
├── netlify.toml               ← Netlify config
└── SETUP-GUIDE.md             ← This file
```

---

## Step-by-Step Deployment

### 1. Create Accounts (All Free)

- **GitHub**: github.com — for storing your code
- **Netlify** OR **Vercel**: for hosting (pick one)
  - Netlify: netlify.com
  - Vercel: vercel.com
- **Stripe**: stripe.com — for card payments
- **PayPal Business**: paypal.com/business — for PayPal payments
- **Domain** (optional): namecheap.com or similar (~$10/year for a .com)

### 2. Set Up Stripe

1. Go to **stripe.com** and create a free account
2. Complete their onboarding (name, bank account for payouts)
3. Go to **Developers → API Keys**
4. You'll see two keys:
   - **Publishable key** (starts with `pk_`) — used on the frontend (not needed for this setup)
   - **Secret key** (starts with `sk_`) — used in the serverless function. **Keep this private!**
5. Copy the **Secret key** — you'll need it in step 5

### 3. Set Up Your Code on GitHub

1. Go to github.com and create a **new repository**
2. Create a Vite React project locally (or use any React setup):

```bash
npm create vite@latest my-store -- --template react
cd my-store
npm install stripe @stripe/stripe-js
```

3. Replace `src/App.jsx` with the contents of `store.jsx`
4. Copy the `netlify/` folder into your project root
5. Copy `netlify.toml` into your project root
6. Copy `package.json` (merge the dependencies if you already have one)
7. Push to GitHub:

```bash
git add .
git commit -m "Initial store"
git push origin main
```

### 4. Deploy to Netlify

1. Go to **netlify.com** → Sign up with GitHub
2. Click **"Add new site"** → **"Import an existing project"**
3. Select your GitHub repository
4. Build settings should auto-detect:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. Click **"Deploy site"**

### 5. Add Environment Variables (CRITICAL)

In Netlify:
1. Go to **Site settings → Environment variables**
2. Add these:

| Key                      | Value                          |
|--------------------------|--------------------------------|
| `STRIPE_SECRET_KEY`      | `sk_live_your_key_here`       |
| `STRIPE_WEBHOOK_SECRET`  | (from step 6 below)           |

⚠️ **NEVER put your secret key in your frontend code or GitHub repo!**

### 6. Set Up Stripe Webhook

1. In Stripe Dashboard → **Developers → Webhooks**
2. Click **"Add endpoint"**
3. Enter your URL:
   - Netlify: `https://your-site-name.netlify.app/.netlify/functions/stripe-webhook`
4. Select event: **`checkout.session.completed`**
5. Click **"Add endpoint"**
6. Click **"Reveal signing secret"** — copy it
7. Add it as `STRIPE_WEBHOOK_SECRET` in Netlify environment variables (step 5)

### 7. Add Custom Domain (Optional)

1. Buy a domain from Namecheap (~$10/year)
2. In Netlify: **Domain settings → Add custom domain**
3. Follow their instructions to point your domain's DNS
4. Netlify gives you free SSL automatically

### 8. Go Live with Stripe

1. By default Stripe is in **test mode** — card payments won't actually charge
2. Use test card `4242 4242 4242 4242` with any future date and any CVC
3. When ready to take real payments:
   - Complete Stripe's verification (they need ID/business info)
   - Switch to **live mode** in Stripe dashboard
   - Update your `STRIPE_SECRET_KEY` environment variable to the live key (starts with `sk_live_`)
   - Update your webhook to use the live endpoint

### 9. Configure Your Store

1. Visit your live site → click **Admin**
2. Default password: `Admin1234!` (change this immediately!)
3. Go to **Settings**:
   - Set your store name
   - Set your PayPal email
   - Set your return address for shipping labels
4. Go to **Products** → add your real inventory

---

## How Payments Work

### Credit/Debit Cards (Stripe)
1. Customer adds items → goes to checkout
2. Fills shipping info → selects "Credit/Debit Card"
3. Clicks "Pay with Card" → **redirected to Stripe's secure page**
4. Enters card info on Stripe (your site never sees card numbers)
5. Stripe charges the card → redirects back to your site
6. Stripe sends a webhook to confirm payment server-side
7. Money appears in your Stripe account (minus ~2.9% + $0.30 fee)
8. Stripe deposits to your bank account (usually 2 business days)

### PayPal
1. Customer clicks "Pay with PayPal" → sent to PayPal
2. Pays on PayPal's site
3. Comes back and clicks "Record Order"
4. Money goes to your PayPal account

---

## Cost Breakdown

| Service            | Cost                              |
|--------------------|-----------------------------------|
| Netlify hosting    | **Free** (100GB bandwidth/month)  |
| Stripe             | **2.9% + $0.30** per transaction  |
| PayPal             | **2.99% + $0.49** per transaction |
| Domain name        | **~$10–15/year**                  |
| Monthly fees       | **$0**                            |
| Platform fees      | **$0**                            |

Example: You sell a $50 item via Stripe → you pay $1.75 in fees → you keep $48.25

---

## Vercel Alternative

If you prefer Vercel over Netlify:
1. Use the `api/create-checkout.js` file instead of the netlify folder
2. In `store.jsx`, change the `STRIPE_FUNCTION_URL` to `/api/create-checkout`
3. Deploy to Vercel the same way (connect GitHub repo)
4. Add environment variables in Vercel's project settings
5. Webhook URL becomes: `https://your-site.vercel.app/api/stripe-webhook`

---

## Testing Checklist

- [ ] Site loads and products display
- [ ] Can create customer account
- [ ] Can add items to cart
- [ ] Checkout flow works (shipping → payment → review)
- [ ] Stripe test payment goes through (use card 4242 4242 4242 4242)
- [ ] Returns to success page after payment
- [ ] PayPal button opens PayPal
- [ ] Admin login works
- [ ] Can add/edit/delete products
- [ ] Can create shipping labels
- [ ] Can mark orders as shipped
- [ ] Shipping labels print correctly

---

## Security Features Built In

- SHA-256 password hashing with unique salts
- 5 failed login attempts = 15 minute lockout
- Sessions expire after 2 hours
- Passwords require uppercase + lowercase + number + 8 chars
- All user input sanitized against XSS
- Card numbers never touch your server (Stripe handles everything)
- Webhook signature verification prevents spoofed payments
- Cryptographically random session tokens and user IDs
