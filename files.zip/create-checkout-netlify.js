// ─────────────────────────────────────────────
// Netlify Serverless Function: Stripe Checkout
// File: netlify/functions/create-checkout.js
// ─────────────────────────────────────────────
// This creates a secure Stripe Checkout Session.
// The customer's card info goes directly to Stripe's
// servers — your site never touches it.

const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event) => {
  // Only allow POST
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  // CORS headers so your frontend can call this
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
  };

  // Handle preflight
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  try {
    const { items, customerEmail, orderId } = JSON.parse(event.body);

    // Validate input
    if (!items || !Array.isArray(items) || items.length === 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "No items provided" }),
      };
    }

    // Build Stripe line items from your cart
    const line_items = items.map((item) => ({
      price_data: {
        currency: "usd",
        product_data: {
          name: item.name,
          // You can add images here too:
          // images: ["https://yoursite.com/images/product.jpg"],
        },
        unit_amount: Math.round(item.price * 100), // Stripe uses cents
      },
      quantity: item.qty,
    }));

    // Create the Checkout Session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      mode: "payment",
      line_items,
      customer_email: customerEmail || undefined,
      metadata: {
        orderId: orderId || "",
      },
      // Where to send the customer after payment
      success_url: `${process.env.URL || "https://yoursite.com"}?payment=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.URL || "https://yoursite.com"}?payment=cancelled`,
      // Optional: collect shipping address via Stripe
      shipping_address_collection: {
        allowed_countries: ["US", "CA", "GB", "AU"],
      },
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ sessionId: session.id, url: session.url }),
    };
  } catch (error) {
    console.error("Stripe error:", error.message);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "Payment session creation failed" }),
    };
  }
};
